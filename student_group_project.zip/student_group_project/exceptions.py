class GroupFullError(Exception):

    def __init__(self, message="Cannot add student: group is full"):
        super().__init__(message)